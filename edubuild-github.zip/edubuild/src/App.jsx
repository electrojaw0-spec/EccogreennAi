import { useState, useEffect, useRef } from "react";

const FIELDS = {
  electrical: { label:"Electrical & Electronics", icon:"⚡", color:"#d97706", light:"#fde68a", topics:["IoT & Smart Devices","Embedded Systems","Power Electronics","Signal Processing","Robotics","Renewable Energy","Telecommunications","PCB Design"], fact:"Did you know? The first integrated circuit was invented in 1958! 🧠" },
  civil:       { label:"Civil Engineering",          icon:"🏗️", color:"#059669", light:"#a7f3d0", topics:["Structural Design","Water Resources","Transportation","Geotechnical","Environmental","Construction Mgmt","Smart Infrastructure","Disaster Management"], fact:"Fun fact: The Great Wall of China used sticky rice as mortar! 🏯" },
  mechanical:  { label:"Mechanical Engineering",     icon:"⚙️", color:"#7c3aed", light:"#ddd6fe", topics:["Thermodynamics","Fluid Mechanics","Manufacturing","Robotics & Automation","HVAC","Automotive","Aerospace","Materials Science"], fact:"Cool fact: Steam engines sparked the Industrial Revolution in the 1760s! 🔥" },
};
const LEVELS = [
  { id:"Beginner",      label:"Beginner 🌱",      desc:"Year 1–2 student" },
  { id:"Intermediate",  label:"Intermediate 🌿",  desc:"Year 2–3 student" },
  { id:"Advanced",      label:"Advanced 🌳",       desc:"Final year student" },
  { id:"Research Level",label:"Research 🔬",       desc:"Postgrad / thesis" },
];
const WELCOME = `Hey there! 👋 Welcome — I'm so glad you stopped by!\n\nI'm **Eco Green**, your personal AI engineering mentor, and I'm genuinely here to help you:\n\n💡 Turn your abstract ideas into real projects\n🛠️ Plan your build step by step\n📚 Find the right tools and resources\n⚡ Answer any engineering question you have\n\n*"The energy that moves with you — let's save the world by saving energy!"* 🌍\n\nSo, what are you working on? I can't wait to hear your ideas! 😊`;
const SYS = `You are Eco Green — a warm, friendly, encouraging AI engineering mentor for university students, created by Modou Jaw (Electrical & Electronics Engineering student, Year 3 Semester 2, University of Applied Science Engineering and Technology (USET)) as part of the Eco Green initiative. Your mission is to help students bring their abstract ideas to life. Speak like a supportive, knowledgeable older student. Use simple language. Use **bold** for key terms. Add an emoji or two. Specialise in Electrical, Civil, and Mechanical Engineering.`;

// ─── API KEY ─────────────────────────────────────────────────────────────────
// Priority: 1) Vite env var (build-time)  2) localStorage (user-entered at runtime)
function getApiKey() {
  return import.meta.env.VITE_ANTHROPIC_KEY || localStorage.getItem("edubuild_api_key") || "";
}

async function callClaude(userPrompt, systemOverride) {
  const key = getApiKey();
  if (!key) throw new Error("NO_KEY");
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": key,
      "anthropic-version": "2023-06-01",
      "anthropic-dangerous-allow-browser": "true",
    },
    body: JSON.stringify({
      model: "claude-sonnet-4-20250514",
      max_tokens: 1200,
      system: systemOverride || SYS,
      messages: [{ role: "user", content: userPrompt }],
    }),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data?.error?.message || res.statusText);
  return data?.content?.[0]?.text || "";
}

async function callClaudeChat(messages, systemOverride) {
  const key = getApiKey();
  if (!key) throw new Error("NO_KEY");
  const mapped = messages.filter(m => m.role==="user"||m.role==="assistant").map(m => ({ role:m.role, content:m.content||"" }));
  const merged = [];
  for (const m of mapped) {
    if (merged.length && merged[merged.length-1].role === m.role) merged[merged.length-1].content += " " + m.content;
    else merged.push({...m});
  }
  while (merged.length && merged[0].role==="assistant") merged.shift();
  if (!merged.length) throw new Error("Nothing to send.");
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": key,
      "anthropic-version": "2023-06-01",
      "anthropic-dangerous-allow-browser": "true",
    },
    body: JSON.stringify({ model:"claude-sonnet-4-20250514", max_tokens:1200, system:systemOverride||SYS, messages:merged }),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data?.error?.message || res.statusText);
  return data?.content?.[0]?.text || "";
}

function mdRender(t) {
  return t.replace(/\*\*(.*?)\*\*/g,"<strong>$1</strong>").replace(/\*(.*?)\*/g,"<em>$1</em>").replace(/\n/g,"<br/>");
}

function Confetti({ trigger }) {
  const ref = useRef(null);
  useEffect(() => {
    if (!trigger || !ref.current) return;
    ref.current.innerHTML = "";
    const colors = ["#10b981","#f59e0b","#8b5cf6","#f43f5e","#3b82f6","#ec4899","#14b8a6"];
    for (let i = 0; i < 40; i++) {
      const p = document.createElement("div");
      const sz = 6 + Math.random()*10, isCircle = Math.random()>0.4;
      p.style.cssText = `position:absolute;left:${5+Math.random()*90}%;top:10%;width:${sz}px;height:${sz}px;background:${colors[Math.floor(Math.random()*colors.length)]};border-radius:${isCircle?"50%":"3px"};animation:confettiFall ${1.5+Math.random()*0.8}s ${Math.random()*0.5}s forwards`;
      ref.current.appendChild(p);
    }
    const t = setTimeout(() => { if(ref.current) ref.current.innerHTML=""; }, 2500);
    return () => clearTimeout(t);
  }, [trigger]);
  return <div ref={ref} style={{ position:"fixed", inset:0, pointerEvents:"none", zIndex:9999 }} />;
}

export default function EduBuild() {
  const [page, setPage]             = useState("hero");
  const [dark, setDark]             = useState(true);
  const [selField, setSelField]     = useState(null);
  const [selTopic, setSelTopic]     = useState("");
  const [selLevel, setSelLevel]     = useState("Intermediate");
  const [ideas, setIdeas]           = useState([]);
  const [saved, setSaved]           = useState([]);
  const [generating, setGenerating] = useState(false);
  const [confettiKey, setConfettiKey] = useState(0);
  const [chatHist, setChatHist]     = useState([{ role:"assistant", content:WELCOME }]);
  const [chatInput, setChatInput]   = useState("");
  const [chatBusy, setChatBusy]     = useState(false);
  const [buildChip, setBuildChip]   = useState(null);
  const chatEndRef = useRef(null);
  const [apiKey, setApiKey]         = useState(() => localStorage.getItem("edubuild_api_key") || import.meta.env.VITE_ANTHROPIC_KEY || "");
  const [showKeyModal, setShowKeyModal] = useState(false);

  // Check key on load
  useEffect(() => {
    if (!getApiKey()) setShowKeyModal(true);
  }, []);

  const saveKey = (k) => {
    localStorage.setItem("edubuild_api_key", k);
    setApiKey(k);
    setShowKeyModal(false);
  };

  useEffect(() => { chatEndRef.current?.scrollIntoView({ behavior:"smooth" }); }, [chatHist, chatBusy]);

  const showPage = (p) => {
    setPage(p);
    if (p==="chat" && chatHist.length===0) setChatHist([{role:"assistant",content:WELCOME}]);
  };

  // ─── GLOBAL STYLES ───────────────────────────────────────────────────────
  const G = `
    @import url('https://fonts.googleapis.com/css2?family=Nunito:wght@400;500;600;700;800;900&family=Lora:ital,wght@0,600;0,700;1,600;1,700&display=swap');
    *, *::before, *::after { box-sizing:border-box; margin:0; padding:0; }

    :root {
      --brand:#10b981;
      --brand2:#34d399;
      --brand3:#d1fae5;
      --brand4:#ecfdf5;

      --bg:${dark?"#0d1f16":"#f5fbf7"};
      --bg2:${dark?"#111f18":"#edfaf3"};
      --surface:${dark?"#162b1f":"#ffffff"};
      --surface2:${dark?"#0f1e14":"#f0faf5"};
      --card:${dark?"#1a3326cc":"#ffffffee"};
      --border:${dark?"#1e3d2a":"#d0ead9"};
      --border2:${dark?"#2a5238":"#a8d8bc"};
      --text:${dark?"#e2f5ea":"#1a3328"};
      --text2:${dark?"#86c9a0":"#2d6a4a"};
      --text3:${dark?"#4a8a66":"#5fa882"};

      --shadow:0 4px 24px rgba(16,185,129,0.10);
      --shadow2:0 12px 48px rgba(16,185,129,0.18);
      --amber:#f59e0b;
      --violet:#8b5cf6;
    }

    body { background:var(--bg); color:var(--text); font-family:'Nunito',sans-serif; transition:background 0.35s, color 0.35s; }
    ::selection { background:#bbf7d0; color:#052e16; }
    ::-webkit-scrollbar { width:5px; }
    ::-webkit-scrollbar-track { background:var(--bg); }
    ::-webkit-scrollbar-thumb { background:var(--border2); border-radius:99px; }
    ::-webkit-scrollbar-thumb:hover { background:var(--brand); }

    .leaf-btn {
      padding:14px 32px; border-radius:50px; border:none;
      background:linear-gradient(135deg,#059669,#10b981);
      color:#fff; font-family:'Nunito',sans-serif;
      font-size:15px; font-weight:800; cursor:pointer;
      box-shadow:0 4px 20px rgba(16,185,129,0.38);
      transition:all 0.25s;
    }
    .leaf-btn:hover { transform:translateY(-3px); box-shadow:0 8px 32px rgba(16,185,129,0.5); }

    .ghost-btn {
      padding:14px 32px; border-radius:50px;
      border:2px solid var(--border2);
      background:${dark?"transparent":"#fff"};
      color:var(--text2); font-family:'Nunito',sans-serif;
      font-size:15px; font-weight:700; cursor:pointer; transition:all 0.25s;
    }
    .ghost-btn:hover { background:var(--brand4); border-color:var(--brand); color:#059669; transform:translateY(-2px); }

    .nav-pill {
      padding:8px 16px; border-radius:50px;
      border:1.5px solid transparent;
      background:transparent;
      color:var(--text2); font-family:'Nunito',sans-serif;
      font-size:13px; font-weight:700; cursor:pointer; transition:all 0.2s;
    }
    .nav-pill:hover { background:${dark?"rgba(16,185,129,0.12)":"#d1fae5"}; color:var(--brand); }
    .nav-pill.active { border-color:var(--brand); background:${dark?"rgba(16,185,129,0.14)":"#d1fae5"}; color:#059669; }

    .card {
      background:var(--card);
      border:1.5px solid var(--border);
      border-radius:20px;
      backdrop-filter:blur(12px);
      transition:all 0.28s;
    }
    .card:hover { border-color:var(--border2); box-shadow:var(--shadow); }

    .pill-tag {
      display:inline-flex; align-items:center; gap:6px;
      padding:6px 16px; border-radius:50px;
      background:${dark?"rgba(16,185,129,0.12)":"#d1fae5"};
      border:1px solid var(--border2);
      color:var(--text2); font-size:12px; font-weight:700;
    }

    .eco-bubble { background:var(--surface); border:1.5px solid var(--border); border-radius:4px 20px 20px 20px; }
    .user-bubble { background:linear-gradient(135deg,#059669,#10b981); border-radius:20px 20px 4px 20px; }

    @keyframes fadeUp { from{opacity:0;transform:translateY(18px)} to{opacity:1;transform:translateY(0)} }
    @keyframes fadeIn { from{opacity:0} to{opacity:1} }
    @keyframes floatLeaf { 0%,100%{transform:translateY(0) rotate(-3deg)} 50%{transform:translateY(-14px) rotate(3deg)} }
    @keyframes gentlePulse { 0%,100%{opacity:0.5} 50%{opacity:1} }
    @keyframes spin { to{transform:rotate(360deg)} }
    @keyframes confettiFall { 0%{opacity:1;transform:translateY(0) rotate(0deg)} 100%{opacity:0;transform:translateY(200px) rotate(540deg) scale(0.2)} }
    @keyframes dotBounce { 0%,80%,100%{transform:translateY(0)} 40%{transform:translateY(-8px)} }
    @keyframes shimmer { 0%{background-position:-200% center} 100%{background-position:200% center} }
    @keyframes growIn { from{transform:scaleX(0)} to{transform:scaleX(1)} }
    @keyframes leafWiggle { 0%,100%{transform:rotate(-5deg)} 50%{transform:rotate(5deg)} }
  `;

  // ─── HERO ─────────────────────────────────────────────────────────────────
  const HeroPage = () => (
    <section style={{ paddingTop:0, minHeight:"100vh", position:"relative", overflow:"hidden" }}>
      {/* background */}
      <div style={{ position:"absolute", inset:0, pointerEvents:"none" }}>
        <div style={{ position:"absolute", width:700, height:700, top:-250, right:-200, borderRadius:"50%", background:`radial-gradient(circle,${dark?"rgba(16,185,129,0.07)":"rgba(209,250,229,0.55)"},transparent 70%)` }} />
        <div style={{ position:"absolute", width:450, height:450, bottom:-120, left:-120, borderRadius:"50%", background:`radial-gradient(circle,${dark?"rgba(52,211,153,0.05)":"rgba(167,243,208,0.4)"},transparent 70%)` }} />
        <div style={{ position:"absolute", width:300, height:300, top:"40%", left:"55%", borderRadius:"50%", background:`radial-gradient(circle,${dark?"rgba(245,158,11,0.04)":"rgba(254,243,199,0.6)"},transparent 70%)` }} />
        <div style={{ position:"absolute", inset:0, opacity:dark?0.05:0.14, backgroundImage:"radial-gradient(circle,#10b981 1.5px,transparent 1.5px)", backgroundSize:"36px 36px" }} />
      </div>

      <div style={{ position:"relative", zIndex:1, maxWidth:820, margin:"0 auto", padding:"120px 32px 80px", textAlign:"center" }}>
        {/* creator badge */}
        <div style={{ display:"inline-flex", alignItems:"center", gap:8, padding:"9px 20px", borderRadius:99, background:dark?"rgba(16,185,129,0.12)":"#d1fae5", border:"1.5px solid var(--border2)", fontSize:13, color:"var(--text2)", fontWeight:700, marginBottom:32, animation:"fadeUp 0.5s ease both", boxShadow:"var(--shadow)" }}>
          👑 &nbsp;Created by <strong style={{color:"#059669"}}>Modou Jaw</strong> &nbsp;·&nbsp; Team Leader, Eco Green
        </div>

        <span style={{ fontSize:82, display:"block", marginBottom:20, animation:"floatLeaf 4s ease-in-out infinite", filter:`drop-shadow(0 10px 28px rgba(16,185,129,${dark?0.45:0.22}))` }}>🌱</span>

        <h1 style={{ fontFamily:"'Lora',serif", fontSize:"clamp(40px,7vw,74px)", fontWeight:700, lineHeight:1.08, marginBottom:18, color:"var(--text)", animation:"fadeUp 0.6s 0.1s ease both" }}>
          Your Engineering<br/>Ideas Start with<br/><em style={{ color:"#059669", fontStyle:"italic" }}>Eco Green</em>
        </h1>

        <p style={{ fontSize:"clamp(15px,2vw,19px)", color:"var(--text2)", marginBottom:14, fontWeight:700, lineHeight:1.65, animation:"fadeUp 0.6s 0.2s ease both" }}>
          🌿 The energy that moves with you —<br/>let's save the world by saving energy.
        </p>
        <p style={{ fontSize:15, color:"var(--text3)", maxWidth:500, margin:"0 auto 52px", lineHeight:1.95, fontWeight:600, animation:"fadeUp 0.6s 0.3s ease both" }}>
          Whether you have a rough sketch or just a spark of an idea, Eco Green gives you the guidance to turn it into something real and meaningful. 🚀
        </p>

        <div style={{ display:"flex", gap:14, justifyContent:"center", flexWrap:"wrap", animation:"fadeUp 0.6s 0.4s ease both", marginBottom:72 }}>
          <button className="leaf-btn" onClick={() => showPage("app")}>✨ Generate Project Ideas</button>
          <button className="ghost-btn" onClick={() => showPage("chat")}>🌿 Chat with Eco Green</button>
        </div>

        <div style={{ display:"flex", justifyContent:"center", gap:56, flexWrap:"wrap", animation:"fadeUp 0.6s 0.5s ease both", paddingBottom:80 }}>
          {[["3","Engineering Fields"],["24+","Speciality Topics"],["∞","Ideas Generated"]].map(([n,l])=>(
            <div key={l} style={{ textAlign:"center" }}>
              <div style={{ fontFamily:"'Lora',serif", fontSize:44, color:"#059669", fontWeight:700, lineHeight:1 }}>{n}</div>
              <div style={{ fontSize:12, color:"var(--text3)", fontWeight:700, marginTop:5, textTransform:"uppercase", letterSpacing:"0.5px" }}>{l}</div>
            </div>
          ))}
        </div>
      </div>

      {/* HOW IT WORKS */}
      <div style={{ padding:"72px 32px", maxWidth:1060, margin:"0 auto" }}>
        <div style={{ marginBottom:48, textAlign:"center" }}>
          <span className="pill-tag" style={{ marginBottom:14, display:"inline-flex" }}>✨ How it works</span>
          <h2 style={{ fontFamily:"'Lora',serif", fontSize:"clamp(26px,4vw,40px)", fontWeight:700, lineHeight:1.2, color:"var(--text)", marginTop:14 }}>
            Three easy steps to<br/><em style={{ color:"#059669" }}>your next great project</em>
          </h2>
        </div>
        <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fit,minmax(250px,1fr))", gap:18 }}>
          {[
            { n:"01", emoji:"💡", color:"#f59e0b", title:"Pick your field & level", desc:"Choose your engineering discipline and study level. We tailor everything to exactly where you are right now.", pg:"app" },
            { n:"02", emoji:"🌿", color:"#10b981", title:"Meet your AI mentor",     desc:"Eco Green explains, plans, and guides you through any project — step by step, with warmth and real clarity.", pg:"chat" },
            { n:"03", emoji:"📌", color:"#8b5cf6", title:"Save your favourites",   desc:"Love an idea? Bookmark it and come back anytime. Your ideas are always waiting, ready to build.", pg:"saved" },
          ].map(c => (
            <div key={c.n} className="card" onClick={() => showPage(c.pg)}
              style={{ padding:"32px 26px", cursor:"pointer", position:"relative", overflow:"hidden" }}
              onMouseEnter={e=>{e.currentTarget.style.transform="translateY(-6px)";e.currentTarget.style.boxShadow="var(--shadow2)";e.currentTarget.querySelector(".step-bar").style.transform="scaleX(1)";}}
              onMouseLeave={e=>{e.currentTarget.style.transform="";e.currentTarget.style.boxShadow="";e.currentTarget.querySelector(".step-bar").style.transform="scaleX(0)";}}>
              <div className="step-bar" style={{ position:"absolute", bottom:0, left:0, right:0, height:4, background:c.color, transform:"scaleX(0)", transformOrigin:"left", transition:"transform 0.35s", borderRadius:"0 0 20px 20px" }} />
              <div style={{ fontSize:11, fontWeight:800, letterSpacing:"2px", color:"var(--text3)", marginBottom:18, textTransform:"uppercase" }}>Step {c.n}</div>
              <span style={{ fontSize:40, display:"block", marginBottom:14 }}>{c.emoji}</span>
              <div style={{ fontFamily:"'Lora',serif", fontSize:19, fontWeight:700, marginBottom:10, color:"var(--text)", lineHeight:1.3 }}>{c.title}</div>
              <div style={{ fontSize:14, color:"var(--text2)", lineHeight:1.85, fontWeight:600 }}>{c.desc}</div>
            </div>
          ))}
        </div>
      </div>

      {/* MANIFESTO */}
      <div style={{ padding:"80px 32px", textAlign:"center", background:dark?"rgba(13,31,22,0.9)":"rgba(236,253,245,0.95)", borderTop:"1px solid var(--border)", borderBottom:"1px solid var(--border)", backdropFilter:"blur(20px)" }}>
        <div style={{ maxWidth:640, margin:"0 auto" }}>
          <span style={{ fontSize:60, display:"block", marginBottom:24, animation:"floatLeaf 5s ease-in-out infinite" }}>🌍</span>
          <blockquote style={{ fontFamily:"'Lora',serif", fontSize:"clamp(20px,3vw,32px)", fontWeight:700, lineHeight:1.45, color:"var(--text)", marginBottom:20, fontStyle:"italic" }}>
            "The energy that moves with you — <em style={{color:"#059669"}}>let's save the world</em> by saving energy, one project at a time."
          </blockquote>
          <p style={{ fontSize:15, color:"var(--text2)", lineHeight:1.95, fontWeight:600, marginBottom:32 }}>
            Every student has the power to make a real difference. Eco Green helps you turn abstract thinking into concrete, green-minded engineering that the world truly needs.
          </p>
          <div style={{ display:"flex", gap:10, justifyContent:"center", flexWrap:"wrap" }}>
            {["🔋 Energy Efficiency","♻️ Sustainability","🌍 Climate Action","⚡ Clean Tech","🌿 Green Engineering","🔬 Innovation"].map(p=>(
              <span key={p} className="pill-tag" style={{ transition:"all 0.2s", cursor:"default" }}
                onMouseEnter={e=>{e.currentTarget.style.background="#059669";e.currentTarget.style.color="#fff";e.currentTarget.style.borderColor="#059669";}}
                onMouseLeave={e=>{e.currentTarget.style.background="";e.currentTarget.style.color="";e.currentTarget.style.borderColor="";}}>
                {p}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* FOUNDER */}
      <div style={{ padding:"72px 32px", maxWidth:780, margin:"0 auto", textAlign:"center" }}>
        <span className="pill-tag" style={{ marginBottom:16, display:"inline-flex" }}>👋 Behind Eco Green</span>
        <h2 style={{ fontFamily:"'Lora',serif", fontSize:"clamp(24px,4vw,40px)", fontWeight:700, lineHeight:1.2, color:"var(--text)", marginBottom:0, marginTop:14 }}>
          Meet the person who<br/><em style={{ color:"#059669" }}>started it all</em>
        </h2>
        <div className="card" style={{ padding:"38px 34px", display:"flex", gap:28, alignItems:"flex-start", maxWidth:660, margin:"28px auto 0", textAlign:"left", flexWrap:"wrap" }}
          onMouseEnter={e=>{e.currentTarget.style.transform="translateY(-4px)";e.currentTarget.style.boxShadow="var(--shadow2)";}}
          onMouseLeave={e=>{e.currentTarget.style.transform="";e.currentTarget.style.boxShadow="";}}>
          <div style={{ display:"flex", flexDirection:"column", alignItems:"center", gap:12, minWidth:100 }}>
            <div style={{ width:90, height:90, borderRadius:"50%", background:"linear-gradient(135deg,#059669,#34d399)", display:"flex", alignItems:"center", justifyContent:"center", fontSize:40, boxShadow:"0 8px 28px rgba(16,185,129,0.35)" }}>👨‍💻</div>
            <div style={{ fontSize:10, color:"#059669", fontWeight:800, background:dark?"rgba(16,185,129,0.12)":"#d1fae5", border:"1px solid var(--border2)", padding:"5px 14px", borderRadius:99, textAlign:"center", lineHeight:1.5, whiteSpace:"nowrap" }}>🌿 Team Leader</div>
          </div>
          <div style={{ flex:1, minWidth:220 }}>
            <h3 style={{ fontFamily:"'Lora',serif", fontSize:22, fontWeight:700, color:"var(--text)", marginBottom:6 }}>Modou Jaw</h3>
            <div style={{ fontSize:13, color:"#059669", fontWeight:700, marginBottom:14 }}>🎓 Electrical & Electronics Engineering · USET · Year 3, Sem 2</div>
            <p style={{ fontSize:14, color:"var(--text2)", lineHeight:1.9, fontWeight:600, marginBottom:18 }}>
              Modou built EduBuild with one mission — to help every student bring their abstract ideas to life. From a rough thought to a working project, Eco Green is your guide every step of the way.
            </p>
            <div style={{ display:"flex", flexWrap:"wrap", gap:8 }}>
              {["⚡ Electrical Eng.","🏫 USET","📅 Year 3 · Sem 2","🌿 Eco Green Founder"].map(b=>(
                <span key={b} className="pill-tag" style={{ fontSize:11 }}>{b}</span>
              ))}
            </div>
          </div>
        </div>
        <div style={{ display:"flex", gap:12, justifyContent:"center", marginTop:24, flexWrap:"wrap" }}>
          <button onClick={()=>showPage("app")} className="ghost-btn" style={{ padding:"10px 22px", fontSize:13 }}>💡 Explore Ideas</button>
          <button onClick={()=>showPage("chat")} className="ghost-btn" style={{ padding:"10px 22px", fontSize:13 }}>🌿 Chat with Eco Green</button>
        </div>
      </div>

      <footer style={{ borderTop:"1px solid var(--border)", padding:"40px 32px", textAlign:"center", background:"var(--surface2)" }}>
        <div style={{ fontFamily:"'Lora',serif", fontSize:22, color:"#059669", marginBottom:6, fontWeight:700 }}>🌿 EduBuild</div>
        <div style={{ fontSize:14, color:"var(--text3)", fontStyle:"italic", marginBottom:6, fontWeight:600 }}>"Eco Green — the energy that moves with you."</div>
        <div style={{ fontSize:13, color:"var(--text3)", marginBottom:20, fontWeight:700 }}>Created with 💚 by <span style={{color:"#059669"}}>Modou Jaw</span> · Electrical & Electronics Engineering Student · <span style={{color:"#059669"}}>USET</span></div>
        <div style={{ display:"flex", gap:24, justifyContent:"center", marginBottom:16, flexWrap:"wrap" }}>
          {[["app","Generate Ideas"],["chat","Eco Green AI"],["saved","Saved Projects"]].map(([pg,lbl])=>(
            <span key={pg} onClick={()=>showPage(pg)} style={{ color:"var(--text3)", fontSize:13, fontWeight:700, cursor:"pointer", transition:"color 0.2s" }}
              onMouseEnter={e=>{e.target.style.color="#059669";}} onMouseLeave={e=>{e.target.style.color="";}}>{lbl}</span>
          ))}
        </div>
        <div style={{ fontSize:12, color:"var(--text3)" }}>© 2025 EduBuild · Eco Green Engineering Hub · Powered by Claude AI</div>
      </footer>
    </section>
  );

  // ─── APP (IDEAS) ──────────────────────────────────────────────────────────
  const AppPage = () => {
    const f = selField ? FIELDS[selField] : null;

    const generateIdeas = async () => {
      if (!selField) return;
      setGenerating(true); setIdeas([]);
      const tc = selTopic ? `specifically in the area of ${selTopic}` : "";
      const prompt = `Generate 4 creative, practical project ideas for a ${selLevel} student in ${FIELDS[selField].label} ${tc}.\n\nFor each idea return JSON:\n{"title":"Project title","description":"2 clear sentences","technologies":["tech1","tech2","tech3","tech4"],"impact":"1 sentence real-world impact","difficulty":3}\n\nDifficulty: 1=very easy, 5=very hard. Return ONLY a valid JSON array of 4 objects. No markdown.`;
      try {
        const res = await callClaude(prompt, "You are a friendly engineering project advisor. Return only valid JSON. No markdown.");
        let clean = res.trim().replace(/```json\n?/g,"").replace(/```\n?/g,"").trim();
        const match = clean.match(/\[[\s\S]*\]/); if (match) clean = match[0];
        const arr = JSON.parse(clean);
        setIdeas((Array.isArray(arr)?arr:[arr]).slice(0,4));
        setConfettiKey(k => k+1);
      } catch(e) { if(e.message==="NO_KEY"){setShowKeyModal(true);}else{alert("Something went wrong — please try again! 😊\n"+e.message);} }
      finally { setGenerating(false); }
    };

    const toggleSave = (idea) => setSaved(prev => {
      const idx = prev.findIndex(s => s.title===idea.title);
      if (idx>=0) { const n=[...prev]; n.splice(idx,1); return n; }
      return [...prev, { ...idea, field:selField }];
    });

    const ideaToChat = (idea) => {
      const msg = `Hi Eco Green! I'm excited about: **${idea.title}**. ${idea.description} Help me plan how to build it step by step!`;
      setChatHist([{ role:"user", content:msg }]);
      setBuildChip(idea.title); showPage("chat"); setChatBusy(true);
      callClaude(msg, SYS+" Help this student build their project step by step. Use **bold** for key points. Be encouraging and warm!")
        .then(r => setChatHist([{role:"user",content:msg},{role:"assistant",content:r}]))
        .catch(e => setChatHist([{role:"user",content:msg},{role:"assistant",content:"⚠️ "+e.message}]))
        .finally(() => setChatBusy(false));
    };

    const Hdr = ({ n, label, color }) => (
      <div style={{ display:"flex", alignItems:"center", gap:10, marginBottom:16 }}>
        <div style={{ width:30, height:30, borderRadius:"50%", background:color||"#059669", display:"flex", alignItems:"center", justifyContent:"center", fontSize:13, fontWeight:800, color:"#fff", flexShrink:0, boxShadow:`0 4px 12px ${color||"#059669"}55` }}>{n}</div>
        <span style={{ fontSize:12, fontWeight:800, color:"var(--text2)", letterSpacing:"0.5px", textTransform:"uppercase" }}>{label}</span>
      </div>
    );

    return (
      <div style={{ paddingTop:66, minHeight:"100vh", background:"var(--bg)" }}>
        <div style={{ maxWidth:900, margin:"0 auto", padding:"40px 24px" }}>
          <h2 style={{ fontFamily:"'Lora',serif", fontSize:28, fontWeight:700, color:"var(--text)", marginBottom:6 }}>💡 Project Idea Generator</h2>
          <p style={{ fontSize:14, color:"var(--text3)", marginBottom:28, fontWeight:600 }}>Tell us your field and level — we'll turn your ideas into real, buildable projects! 🎉</p>

          {/* status banner */}
          <div onClick={() => setShowKeyModal(true)} style={{ display:"flex", alignItems:"center", gap:12, padding:"14px 18px", borderRadius:16, background:apiKey?(dark?"rgba(16,185,129,0.1)":"#d1fae5"):(dark?"rgba(245,158,11,0.1)":"#fef3c7"), border:`1.5px solid ${apiKey?"var(--border2)":"#fcd34d"}`, marginBottom:32, cursor:"pointer", transition:"all 0.2s" }}>
            <div style={{ width:10, height:10, borderRadius:"50%", background:apiKey?"#10b981":"#f59e0b", animation:"gentlePulse 2s infinite", flexShrink:0 }} />
            <div style={{ flex:1 }}>
              <div style={{ fontSize:13, color:apiKey?"#059669":"#b45309", fontWeight:800 }}>{apiKey ? "Claude AI · Ready ✅" : "API Key Required ⚠️"}</div>
              <div style={{ fontSize:11, color:"var(--text3)", fontWeight:600 }}>{apiKey ? "Powered by Claude AI · Click to change key" : "Click here to add your Claude API key"}</div>
            </div>
            <span style={{ fontSize:18 }}>{apiKey ? "🔑" : "➕"}</span>
          </div>

          {/* STEP 1 */}
          <div style={{ marginBottom:32 }}>
            <Hdr n="1" label="Which engineering field are you in?" color={f?.color||"#059669"} />
            <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fit,minmax(200px,1fr))", gap:14 }}>
              {Object.entries(FIELDS).map(([k,fld]) => {
                const active = selField===k;
                return (
                  <div key={k} className="card" onClick={() => { setSelField(k); setSelTopic(""); setIdeas([]); }}
                    style={{ padding:"22px 18px", cursor:"pointer", borderColor:active?fld.color:"var(--border)", background:active?`${fld.color}12`:"var(--card)", boxShadow:active?`0 4px 24px ${fld.color}33`:"none", transform:active?"translateY(-2px)":"" }}>
                    <span style={{ fontSize:34, marginBottom:12, display:"block" }}>{fld.icon}</span>
                    <div style={{ fontWeight:800, fontSize:14, color:active?fld.color:"var(--text)", marginBottom:active?8:0 }}>{fld.label}</div>
                    {active && <div style={{ fontSize:11, color:"var(--text3)", lineHeight:1.65, fontWeight:600, marginTop:8, background:"var(--bg)", padding:"8px 10px", borderRadius:10 }}>{fld.fact}</div>}
                    {active && <div style={{ height:3, background:`linear-gradient(90deg,${fld.color},${fld.light})`, borderRadius:99, marginTop:14, animation:"growIn 0.4s ease" }} />}
                  </div>
                );
              })}
            </div>
          </div>

          {/* STEP 2 */}
          {selField && (
            <div style={{ marginBottom:28 }}>
              <Hdr n="2" label="Any specific topic? (optional 😊)" color={f.color} />
              <div style={{ display:"flex", flexWrap:"wrap", gap:8 }}>
                {["Any Topic",...f.topics].map(t => {
                  const val = t==="Any Topic"?"":t; const active = selTopic===val;
                  return <button key={t} onClick={() => setSelTopic(val)}
                    style={{ padding:"8px 18px", borderRadius:99, border:`1.5px solid ${active?f.color:"var(--border)"}`, background:active?`${f.color}14`:"transparent", color:active?f.color:"var(--text2)", fontSize:13, fontWeight:700, cursor:"pointer", transition:"all 0.15s", fontFamily:"'Nunito',sans-serif" }}>
                    {active?"✓ ":""}{t}
                  </button>;
                })}
              </div>
            </div>
          )}

          {/* STEP 3 */}
          {selField && (
            <div style={{ marginBottom:32 }}>
              <Hdr n="3" label="Where are you in your studies?" color={f.color} />
              <div style={{ display:"grid", gridTemplateColumns:"repeat(2,1fr)", gap:10, maxWidth:480 }}>
                {LEVELS.map(l => {
                  const active = selLevel===l.id;
                  return <div key={l.id} className="card" onClick={() => setSelLevel(l.id)}
                    style={{ padding:"14px 18px", cursor:"pointer", borderColor:active?f.color:"var(--border)", background:active?`${f.color}12`:"var(--card)" }}>
                    <div style={{ fontWeight:800, fontSize:13, color:active?f.color:"var(--text)" }}>{l.label}</div>
                    <div style={{ fontSize:11, color:"var(--text3)", fontWeight:600, marginTop:2 }}>{l.desc}</div>
                  </div>;
                })}
              </div>
            </div>
          )}

          {/* GENERATE BUTTON */}
          {selField && (
            <button disabled={generating} onClick={generateIdeas} className={generating?"":"leaf-btn"}
              style={{ width:"100%", maxWidth:460, padding:"16px 24px", borderRadius:16, border:"none", fontFamily:"'Nunito',sans-serif", fontWeight:800, fontSize:15, cursor:generating?"not-allowed":"pointer", display:"flex", alignItems:"center", justifyContent:"center", gap:10, marginBottom:40,
                ...(generating ? { background:"var(--border)", color:"var(--text3)", boxShadow:"none" } : {}) }}>
              {generating
                ? <><span style={{ display:"inline-block", width:18, height:18, border:"2px solid rgba(255,255,255,0.3)", borderTopColor:"#fff", borderRadius:"50%", animation:"spin 0.8s linear infinite" }} /> Crafting your ideas...</>
                : "✨ Generate My Project Ideas"}
            </button>
          )}

          {!selField && (
            <div style={{ textAlign:"center", padding:"60px 0" }}>
              <div style={{ fontSize:50, marginBottom:14 }}>👆</div>
              <div style={{ color:"var(--text3)", fontSize:15, fontWeight:600 }}>Pick your engineering field above to get started!</div>
            </div>
          )}

          {/* IDEAS */}
          {ideas.length > 0 && (
            <div>
              <div style={{ display:"flex", alignItems:"center", gap:14, marginBottom:24 }}>
                <div style={{ height:1, flex:1, background:"var(--border)" }} />
                <span style={{ fontSize:11, color:"var(--text3)", fontWeight:800, letterSpacing:"1px" }}>🎉 YOUR IDEAS ARE READY!</span>
                <div style={{ height:1, flex:1, background:"var(--border)" }} />
              </div>
              <div style={{ display:"grid", gap:18 }}>
                {ideas.map((idea,i) => {
                  const sv = !!saved.find(s => s.title===idea.title);
                  const diff = Math.max(1,Math.min(5,idea.difficulty||3));
                  const fld = FIELDS[selField];
                  return (
                    <div key={i} className="card" style={{ overflow:"hidden" }}
                      onMouseEnter={e=>{e.currentTarget.style.transform="translateY(-4px)"; e.currentTarget.style.boxShadow="var(--shadow2)";}}
                      onMouseLeave={e=>{e.currentTarget.style.transform=""; e.currentTarget.style.boxShadow="";}}>
                      <div style={{ height:5, background:`linear-gradient(90deg,${fld.color},${fld.light})` }} />
                      <div style={{ padding:"22px 24px" }}>
                        <div style={{ fontSize:11, fontWeight:800, marginBottom:8, letterSpacing:"0.5px", color:fld.color, textTransform:"uppercase" }}>Idea {i+1} · {"⭐".repeat(diff)}{"☆".repeat(5-diff)}</div>
                        <div style={{ fontFamily:"'Lora',serif", fontSize:20, fontWeight:700, color:"var(--text)", marginBottom:10, lineHeight:1.3 }}>{idea.title}</div>
                        <div style={{ color:"var(--text2)", fontSize:14, lineHeight:1.9, marginBottom:16, fontWeight:600 }}>{idea.description}</div>
                        <div style={{ display:"flex", flexWrap:"wrap", gap:7, marginBottom:16 }}>
                          {idea.technologies?.map(t => <span key={t} style={{ padding:"5px 14px", borderRadius:99, fontSize:12, fontWeight:700, background:`${fld.color}14`, border:`1.5px solid ${fld.color}44`, color:fld.color }}>{t}</span>)}
                        </div>
                        <div style={{ background:dark?"rgba(16,185,129,0.08)":"#d1fae5", borderRadius:12, padding:"10px 14px", fontSize:13, color:"var(--text2)", marginBottom:18, fontWeight:600, border:"1px solid var(--border)" }}>
                          🌍 <strong>Why it matters:</strong> {idea.impact}
                        </div>
                        <div style={{ display:"flex", gap:10, flexWrap:"wrap" }}>
                          <button className="leaf-btn" onClick={() => ideaToChat(idea)} style={{ flex:1, minWidth:160, padding:"11px 18px", borderRadius:12, fontSize:13, display:"flex", alignItems:"center", justifyContent:"center", gap:7 }}>
                            🌿 Build with Eco Green
                          </button>
                          <button onClick={() => toggleSave(idea)}
                            style={{ padding:"11px 20px", borderRadius:12, fontFamily:"'Nunito',sans-serif", fontSize:13, cursor:"pointer", fontWeight:700, transition:"all 0.15s", border:`1.5px solid ${sv?fld.color:"var(--border2)"}`, background:sv?`${fld.color}14`:"transparent", color:sv?fld.color:"var(--text3)" }}>
                            {sv?"✓ Saved!":"📌 Save"}
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
              <button onClick={generateIdeas}
                style={{ marginTop:16, width:"100%", padding:14, borderRadius:12, border:"2px solid var(--border)", background:"transparent", color:"var(--text3)", fontFamily:"'Nunito',sans-serif", fontSize:13, fontWeight:700, cursor:"pointer", transition:"all 0.2s" }}
                onMouseEnter={e=>{e.target.style.borderColor="#10b981";e.target.style.color="#059669";e.target.style.background=dark?"rgba(16,185,129,0.08)":"#d1fae5";}}
                onMouseLeave={e=>{e.target.style.borderColor="var(--border)";e.target.style.color="var(--text3)";e.target.style.background="transparent";}}>
                🔄 Give Me 4 Fresh Ideas
              </button>
            </div>
          )}
        </div>
      </div>
    );
  };

  // ─── CHAT ─────────────────────────────────────────────────────────────────
  const ChatPage = () => {
    const sendMsg = async () => {
      const msg = chatInput.trim(); if (!msg||chatBusy) return;
      setChatInput("");
      const newHist = [...chatHist, {role:"user",content:msg}];
      setChatHist(newHist); setChatBusy(true);
      try {
        const reply = await callClaudeChat(newHist);
        setChatHist([...newHist, {role:"assistant",content:reply||"Sorry, got an empty response!"}]);
      } catch(e) { if(e.message==="NO_KEY"){setShowKeyModal(true);setChatBusy(false);}else{setChatHist([...newHist, {role:"assistant",content:"⚠️ "+e.message}]);} }
      finally { if(!showKeyModal) setChatBusy(false); }
    };
    const sendQuick = async (msg) => {
      if (chatBusy) return;
      const newHist = [...chatHist, {role:"user",content:msg}];
      setChatHist(newHist); setChatBusy(true);
      try {
        const reply = await callClaudeChat(newHist);
        setChatHist([...newHist, {role:"assistant",content:reply}]);
      } catch(e) { setChatHist([...newHist, {role:"assistant",content:"⚠️ "+e.message}]); }
      finally { setChatBusy(false); }
    };
    const showPrompts = chatHist.filter(m=>m.role==="user").length===0;

    return (
      <div style={{ paddingTop:66, height:"100vh", display:"flex", flexDirection:"column" }}>
        <div style={{ flex:1, display:"flex", flexDirection:"column", maxWidth:720, width:"100%", margin:"0 auto", padding:"0 20px", overflow:"hidden" }}>
          {/* header */}
          <div style={{ display:"flex", alignItems:"center", gap:14, padding:"18px 0 14px", borderBottom:"1px solid var(--border)", flexShrink:0 }}>
            <div style={{ width:52, height:52, borderRadius:"50%", background:"linear-gradient(135deg,#059669,#34d399)", display:"flex", alignItems:"center", justifyContent:"center", fontSize:26, flexShrink:0, boxShadow:"0 4px 20px rgba(16,185,129,0.4)" }}>🌿</div>
            <div style={{ flex:1 }}>
              <div style={{ fontFamily:"'Lora',serif", fontSize:18, fontWeight:700, color:"#059669" }}>Eco Green</div>
              <div style={{ fontSize:12, color:"var(--text3)", display:"flex", alignItems:"center", gap:6, fontWeight:600 }}>
                <span style={{ width:7, height:7, borderRadius:"50%", background:"#10b981", animation:"gentlePulse 2s infinite", display:"inline-block" }} />
                Your AI Engineering Mentor · Always here for you 💚
              </div>
            </div>
            {buildChip && (
              <div style={{ background:dark?"rgba(16,185,129,0.1)":"#d1fae5", border:"1.5px solid var(--border2)", borderRadius:12, padding:"8px 12px", fontSize:11, color:"#059669", maxWidth:160, textAlign:"right", flexShrink:0, lineHeight:1.6, fontWeight:700 }}>
                🔨 Building:<br/><strong style={{fontSize:12}}>{buildChip}</strong>
              </div>
            )}
          </div>

          {/* quick prompts */}
          {showPrompts && (
            <div style={{ padding:"12px 0 6px", display:"flex", flexWrap:"wrap", gap:7, flexShrink:0 }}>
              {["How do I start a final year project? 🎓","What tools do I need for IoT? 🔌","Suggest a civil engineering project 🏗️","How do I write a project proposal? 📄"].map(q=>(
                <button key={q} onClick={()=>sendQuick(q)}
                  style={{ padding:"7px 14px", borderRadius:99, border:"1.5px solid var(--border)", background:"var(--surface)", color:"var(--text2)", fontSize:12, fontWeight:700, cursor:"pointer", fontFamily:"'Nunito',sans-serif", transition:"all 0.15s" }}
                  onMouseEnter={e=>{e.currentTarget.style.borderColor="#10b981";e.currentTarget.style.color="#059669";e.currentTarget.style.background=dark?"rgba(16,185,129,0.1)":"#d1fae5";}}
                  onMouseLeave={e=>{e.currentTarget.style.borderColor="var(--border)";e.currentTarget.style.color="var(--text2)";e.currentTarget.style.background="var(--surface)";}}>
                  {q}
                </button>
              ))}
            </div>
          )}

          {/* messages */}
          <div style={{ flex:1, overflowY:"auto", padding:"14px 0", display:"flex", flexDirection:"column", gap:14 }}>
            {chatHist.map((msg,i) => (
              <div key={i} style={{ display:"flex", gap:10, flexDirection:msg.role==="user"?"row-reverse":"row", alignItems:"flex-end", animation:"fadeUp 0.2s ease" }}>
                {msg.role==="assistant" && (
                  <div style={{ width:34, height:34, borderRadius:"50%", background:"linear-gradient(135deg,#059669,#34d399)", display:"flex", alignItems:"center", justifyContent:"center", fontSize:16, flexShrink:0 }}>🌿</div>
                )}
                <div className={msg.role==="assistant"?"eco-bubble":"user-bubble"}
                  style={{ maxWidth:"76%", padding:"13px 16px", fontSize:14, lineHeight:1.85, fontWeight:600,
                    color:msg.role==="user"?"#fff":"var(--text2)",
                    boxShadow:msg.role==="user"?"0 4px 16px rgba(16,185,129,0.35)":"0 2px 10px rgba(0,0,0,0.06)" }}
                  dangerouslySetInnerHTML={{ __html:mdRender(msg.content) }} />
              </div>
            ))}
            {chatBusy && (
              <div style={{ display:"flex", gap:10, alignItems:"flex-end" }}>
                <div style={{ width:34, height:34, borderRadius:"50%", background:"linear-gradient(135deg,#059669,#34d399)", display:"flex", alignItems:"center", justifyContent:"center", fontSize:16, flexShrink:0 }}>🌿</div>
                <div className="eco-bubble" style={{ padding:"14px 18px" }}>
                  <div style={{ display:"inline-flex", gap:5, alignItems:"center" }}>
                    {[0,1,2].map(i=><span key={i} style={{ width:8, height:8, borderRadius:"50%", background:"#10b981", display:"inline-block", animation:`dotBounce 1.2s ${i*0.2}s infinite ease-in-out` }} />)}
                  </div>
                </div>
              </div>
            )}
            <div ref={chatEndRef} />
          </div>

          {/* input */}
          <div style={{ padding:"14px 0 22px", borderTop:"1px solid var(--border)", display:"flex", gap:10, alignItems:"flex-end", flexShrink:0 }}>
            <textarea value={chatInput} onChange={e=>setChatInput(e.target.value)}
              onKeyDown={e=>{ if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();sendMsg();} }}
              placeholder="Ask Eco Green anything... (Enter to send, Shift+Enter for new line)"
              rows={1}
              style={{ flex:1, background:"var(--surface)", border:"1.5px solid var(--border)", borderRadius:16, padding:"13px 17px", color:"var(--text)", fontFamily:"'Nunito',sans-serif", fontSize:14, resize:"none", outline:"none", lineHeight:1.6, maxHeight:110, overflowY:"auto", fontWeight:600, transition:"border-color 0.2s" }}
              onFocus={e=>{e.target.style.borderColor="#10b981";e.target.style.boxShadow="0 0 0 3px rgba(16,185,129,0.15)";}}
              onBlur={e=>{e.target.style.borderColor="var(--border)";e.target.style.boxShadow="none";}} />
            <button onClick={sendMsg} disabled={chatBusy||!chatInput.trim()}
              style={{ width:48, height:48, borderRadius:"50%", border:"none", fontSize:18, display:"flex", alignItems:"center", justifyContent:"center", cursor:chatBusy||!chatInput.trim()?"not-allowed":"pointer", flexShrink:0, transition:"all 0.2s",
                background:chatInput.trim()&&!chatBusy?"linear-gradient(135deg,#059669,#10b981)":"var(--border)",
                color:chatInput.trim()&&!chatBusy?"#fff":"var(--text3)",
                boxShadow:chatInput.trim()&&!chatBusy?"0 4px 16px rgba(16,185,129,0.45)":"none" }}>↑</button>
          </div>
        </div>
      </div>
    );
  };

  // ─── SAVED ────────────────────────────────────────────────────────────────
  const SavedPage = () => {
    const startChat = (idea) => {
      const msg = `Hi Eco Green! I want to build: **${idea.title}**. ${idea.description} Help me plan it step by step!`;
      setChatHist([{role:"user",content:msg}]); setBuildChip(idea.title); showPage("chat"); setChatBusy(true);
      callClaude(msg, SYS+" Help this student build step by step. Be warm and encouraging!")
        .then(r=>setChatHist([{role:"user",content:msg},{role:"assistant",content:r}]))
        .catch(e=>setChatHist([{role:"user",content:msg},{role:"assistant",content:"⚠️ "+e.message}]))
        .finally(()=>setChatBusy(false));
    };
    return (
      <div style={{ paddingTop:66, minHeight:"100vh", background:"var(--bg)" }}>
        <div style={{ maxWidth:900, margin:"0 auto", padding:"40px 24px" }}>
          <h2 style={{ fontFamily:"'Lora',serif", fontSize:28, fontWeight:700, marginBottom:6, color:"var(--text)" }}>📌 Saved Ideas</h2>
          <p style={{ fontSize:14, color:"var(--text3)", marginBottom:32, fontWeight:600 }}>Your bookmarked projects — ready to build whenever you are! 💪</p>
          {saved.length===0 ? (
            <div style={{ textAlign:"center", padding:"80px 0" }}>
              <span style={{ fontSize:60, marginBottom:16, display:"block" }}>📭</span>
              <div style={{ color:"var(--text3)", fontSize:15, marginBottom:28, fontWeight:600 }}>No saved ideas yet — go generate some! They'll show up here 😊</div>
              <button className="leaf-btn" onClick={()=>showPage("app")}>Go Generate Ideas ✨</button>
            </div>
          ) : (
            <div style={{ display:"grid", gap:16 }}>
              {saved.map((idea,i) => {
                const fld = FIELDS[idea.field];
                return (
                  <div key={i} className="card" style={{ overflow:"hidden" }}
                    onMouseEnter={e=>{e.currentTarget.style.transform="translateY(-3px)";e.currentTarget.style.boxShadow="var(--shadow2)";}}
                    onMouseLeave={e=>{e.currentTarget.style.transform="";e.currentTarget.style.boxShadow="";}}>
                    <div style={{ height:4, background:`linear-gradient(90deg,${fld.color},${fld.light})` }} />
                    <div style={{ padding:"20px 22px" }}>
                      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", gap:12, marginBottom:12 }}>
                        <div>
                          <div style={{ fontSize:11, color:fld.color, fontWeight:800, textTransform:"uppercase", letterSpacing:"0.5px" }}>{fld.icon} {fld.label}</div>
                          <div style={{ fontFamily:"'Lora',serif", fontSize:18, fontWeight:700, color:"var(--text)", marginTop:4, lineHeight:1.3 }}>{idea.title}</div>
                        </div>
                        <button onClick={()=>setSaved(prev=>{const n=[...prev];n.splice(i,1);return n;})}
                          style={{ padding:"6px 12px", borderRadius:8, border:"1px solid #fca5a5", background:"#fef2f2", color:"#ef4444", cursor:"pointer", fontSize:12, fontWeight:700, fontFamily:"'Nunito',sans-serif", flexShrink:0 }}>✕ Remove</button>
                      </div>
                      <p style={{ color:"var(--text2)", fontSize:13, lineHeight:1.85, margin:"0 0 14px", fontWeight:600 }}>{idea.description}</p>
                      <div style={{ display:"flex", flexWrap:"wrap", gap:7, marginBottom:16 }}>
                        {idea.technologies?.map(t=><span key={t} style={{ background:`${fld.color}14`, border:`1.5px solid ${fld.color}44`, color:fld.color, padding:"4px 12px", borderRadius:99, fontSize:12, fontWeight:700 }}>{t}</span>)}
                      </div>
                      <button className="leaf-btn" onClick={()=>startChat(idea)} style={{ padding:"11px 22px", borderRadius:12, fontSize:13, display:"inline-flex", alignItems:"center", gap:7 }}>
                        🌿 Build with Eco Green
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    );
  };

  // ─── NAVBAR ───────────────────────────────────────────────────────────────
  const navItems = [
    { id:"hero",  label:"Home" },
    { id:"app",   label:"💡 Ideas" },
    { id:"chat",  label:"🌿 Eco Green" },
    { id:"saved", label:`📌 Saved${saved.length?` (${saved.length})`:""}`},
  ];

  return (
    <div style={{ fontFamily:"'Nunito',sans-serif", minHeight:"100vh" }}>
      <style>{G}</style>
      <Confetti trigger={confettiKey} />

      {/* NAVBAR */}
      <nav style={{ position:"fixed", top:0, left:0, right:0, zIndex:1000, display:"flex", alignItems:"center", justifyContent:"space-between", padding:"0 32px", height:66,
        background:dark?"rgba(13,31,22,0.93)":"rgba(245,251,247,0.93)",
        backdropFilter:"blur(20px)", borderBottom:"1px solid var(--border)",
        boxShadow:"0 2px 20px rgba(16,185,129,0.07)", transition:"background 0.3s, border-color 0.3s" }}>

        <div onClick={()=>showPage("hero")} style={{ display:"flex", alignItems:"center", gap:10, cursor:"pointer" }}>
          <span style={{ fontSize:28, animation:"leafWiggle 3s ease-in-out infinite", display:"inline-block", filter:"drop-shadow(0 0 8px rgba(16,185,129,0.5))" }}>🌿</span>
          <div>
            <div style={{ fontFamily:"'Lora',serif", fontSize:19, color:"#059669", fontWeight:700, lineHeight:1 }}>EduBuild</div>
            <div style={{ fontSize:9, color:"var(--text3)", letterSpacing:"0.5px", fontWeight:700, textTransform:"uppercase" }}>Eco Green · USET</div>
          </div>
        </div>

        <div style={{ display:"flex", gap:4 }}>
          {navItems.map(n => (
            <button key={n.id} className={`nav-pill${page===n.id?" active":""}`} onClick={()=>showPage(n.id)}>{n.label}</button>
          ))}
        </div>

        <div style={{ display:"flex", alignItems:"center", gap:10 }}>
          <button onClick={()=>setDark(d=>!d)}
            style={{ width:40, height:40, borderRadius:"50%", border:"1.5px solid var(--border2)", background:"var(--surface)", color:"var(--text2)", fontSize:17, cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center", transition:"all 0.2s" }}
            onMouseEnter={e=>{e.currentTarget.style.borderColor="#10b981";e.currentTarget.style.background=dark?"rgba(16,185,129,0.1)":"#d1fae5";}}
            onMouseLeave={e=>{e.currentTarget.style.borderColor="var(--border2)";e.currentTarget.style.background="var(--surface)";}}>
            {dark?"☀️":"🌙"}
          </button>
          <button className="leaf-btn" onClick={()=>showPage("app")} style={{ padding:"9px 20px", fontSize:13 }}>
            Start Building ✨
          </button>
        </div>
      </nav>

      {page==="hero"  && <HeroPage />}
      {page==="app"   && <AppPage />}
      {page==="chat"  && <ChatPage />}
      {page==="saved" && <SavedPage />}

      {/* API KEY MODAL */}
      {showKeyModal && (
        <div style={{ position:"fixed", inset:0, zIndex:99999, background:"rgba(0,0,0,0.65)", backdropFilter:"blur(8px)", display:"flex", alignItems:"center", justifyContent:"center", padding:20 }}>
          <div style={{ background:"var(--surface)", border:"1.5px solid var(--border2)", borderRadius:28, padding:"40px 36px", maxWidth:460, width:"100%", boxShadow:"0 24px 64px rgba(0,0,0,0.4)", textAlign:"center" }}>
            <span style={{ fontSize:52, display:"block", marginBottom:16 }}>🔑</span>
            <h2 style={{ fontFamily:"'Lora',serif", fontSize:22, fontWeight:700, color:"var(--text)", marginBottom:8 }}>Enter your API Key</h2>
            <p style={{ fontSize:14, color:"var(--text3)", lineHeight:1.75, marginBottom:22, fontWeight:600 }}>
              EduBuild uses the <strong>Claude API</strong> to power idea generation and chat.<br/>
              Your key is saved only in your browser — never sent to any server.
            </p>
            <KeyEntry onSave={saveKey} dark={dark} />
            {apiKey && (
              <button onClick={() => setShowKeyModal(false)} style={{ marginTop:12, background:"none", border:"none", color:"var(--text3)", fontSize:13, cursor:"pointer", fontWeight:600, fontFamily:"'Nunito',sans-serif" }}>
                Cancel
              </button>
            )}
            <div style={{ display:"flex", alignItems:"center", gap:8, marginTop:18, padding:"10px 14px", background:dark?"rgba(16,185,129,0.08)":"#d1fae5", borderRadius:10, border:"1px solid var(--border2)" }}>
              <span style={{ fontSize:15, flexShrink:0 }}>🔒</span>
              <span style={{ fontSize:11, color:"var(--text2)", fontWeight:600, textAlign:"left", lineHeight:1.5 }}>Your key stays in your browser's localStorage. It's never shared with anyone.</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── KEY ENTRY HELPER ──────────────────────────────────────────────────────
function KeyEntry({ onSave, dark }) {
  const [val, setVal] = useState("");
  const [show, setShow] = useState(false);
  return (
    <>
      <div style={{ position:"relative", marginBottom:12 }}>
        <input
          type={show?"text":"password"}
          value={val}
          onChange={e=>setVal(e.target.value)}
          onKeyDown={e=>{ if(e.key==="Enter"&&val.trim()) onSave(val.trim()); }}
          placeholder="sk-ant-api03-..."
          style={{ width:"100%", padding:"13px 48px 13px 16px", borderRadius:14, border:"1.5px solid var(--border2)", background:"var(--bg)", color:"var(--text)", fontFamily:"'Nunito',sans-serif", fontSize:14, outline:"none", fontWeight:600 }}
          autoFocus
        />
        <button onClick={()=>setShow(s=>!s)} style={{ position:"absolute", right:14, top:"50%", transform:"translateY(-50%)", background:"none", border:"none", cursor:"pointer", fontSize:16, color:"var(--text3)" }}>
          {show?"🙈":"👁️"}
        </button>
      </div>
      <p style={{ fontSize:11, color:"var(--text3)", marginBottom:16, textAlign:"left", fontWeight:600 }}>
        Get a free key at{" "}
        <a href="https://console.anthropic.com/keys" target="_blank" rel="noopener noreferrer" style={{ color:"#059669", fontWeight:700 }}>console.anthropic.com</a>
      </p>
      <button
        onClick={() => { if(val.trim()) onSave(val.trim()); }}
        disabled={!val.trim()}
        style={{ width:"100%", padding:14, borderRadius:14, border:"none", background:val.trim()?"linear-gradient(135deg,#059669,#10b981)":"var(--border)", color:val.trim()?"#fff":"var(--text3)", fontFamily:"'Nunito',sans-serif", fontSize:15, fontWeight:800, cursor:val.trim()?"pointer":"not-allowed", boxShadow:val.trim()?"0 6px 24px rgba(16,185,129,0.35)":"none", transition:"all 0.2s" }}>
        Save Key & Start Building ✨
      </button>
    </>
  );
}
