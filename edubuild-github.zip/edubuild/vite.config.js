import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  // Replace 'edubuild' with your actual GitHub repository name
  base: '/edubuild/',
})
