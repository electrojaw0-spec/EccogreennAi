# 🌿 EduBuild — Eco Green Engineering Hub

AI-powered engineering project ideas and mentoring for USET students.  
Created by **Modou Jaw** · Electrical & Electronics Engineering · USET

---

## 🚀 Running Locally

```bash
# 1. Install dependencies
npm install

# 2. Create your local env file
cp .env.example .env.local

# 3. Add your Claude API key to .env.local
#    Get one free at: https://console.anthropic.com/keys
#    VITE_ANTHROPIC_KEY=sk-ant-api03-...

# 4. Start the dev server
npm run dev
```

Open http://localhost:5173/edubuild/

---

## 🌐 Deploying to GitHub Pages

### One-time setup

1. **Fork / push** this repo to GitHub

2. Go to **Settings → Pages** → set Source to **"GitHub Actions"**

3. Go to **Settings → Secrets and variables → Actions → New repository secret**  
   - Name: `VITE_ANTHROPIC_KEY`  
   - Value: your Claude API key (`sk-ant-api03-...`)

4. Push to `main` — the workflow auto-deploys to  
   `https://<your-username>.github.io/edubuild/`

### Update `vite.config.js`

Make sure the `base` matches your repo name:

```js
base: '/edubuild/',   // ← change this if your repo has a different name
```

---

## 🔑 API Key — No Build-Time Key?

If you don't add a secret, the app still works — users enter their own Claude API key in a popup when they first visit. The key is saved to their browser's `localStorage` only.

---

## 📁 Project Structure

```
edubuild/
├── src/
│   ├── main.jsx          # React entry point
│   └── App.jsx           # Full application
├── public/               # Static assets
├── .github/workflows/    # Auto-deploy pipeline
├── .env.example          # Template for local env
├── .gitignore
├── index.html
├── package.json
└── vite.config.js
```

---

© 2025 EduBuild · Eco Green Engineering Hub · Powered by Claude AI
